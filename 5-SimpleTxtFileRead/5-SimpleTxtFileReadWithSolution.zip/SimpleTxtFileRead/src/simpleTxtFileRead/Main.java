package simpleTxtFileRead;

public class Main {
	static ApplicationFrame app;
	
	public static void main(String[] args) {
		app = new ApplicationFrame();		
	}
}
